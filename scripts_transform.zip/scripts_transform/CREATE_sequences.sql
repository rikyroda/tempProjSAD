CREATE SEQUENCE seq_tel_iteration;
CREATE SEQUENCE seq_tel_screen;
CREATE SEQUENCE seq_tel_source;
CREATE SEQUENCE seq_tel_date;

