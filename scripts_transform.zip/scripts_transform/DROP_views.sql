DROP VIEW v_last_iteration_info;
DROP VIEW v_data_with_problems;
DROP VIEW v_presencas_user_notenrolled;
